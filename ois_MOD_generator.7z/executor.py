from qf_mng_03 import Mng03


mng_03_obj = Mng03(ss_id=21, year=2021, month=8, output_absolute_file_path='qf_mng_03.xlsx')
v = 1
