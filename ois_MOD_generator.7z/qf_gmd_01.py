# class Equipment:
#     def __init__(self):
